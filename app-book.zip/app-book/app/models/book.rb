class Book < ApplicationRecord
  belongs_to :author

  has_one_attached :image


  has_many :read_books
  has_many :reading_books
  has_many :want_to_read_books
  has_many :reviews

  validates :title, presence: true
  validates :description, presence: true
  validates :author_name, presence: true
end
