class Reader < ApplicationRecord
  has_secure_password
  attr_accessor :password_confirmation

  has_many :books
  has_many :read_books
  has_many :reading_books
  has_many :want_to_read_books
  has_many :reviews


  has_many :read_books_relations, through: :read_books, source: :book
  has_many :reading_books_relations, through: :reading_books, source: :book
  has_many :want_to_read_books_relations, through: :want_to_read_books, source: :book

  validates :email, presence: true, uniqueness: true
  validates :name, presence: true
  validates :password_digest, presence: true
  validates :password_confirmation, presence: true, on: :create



end