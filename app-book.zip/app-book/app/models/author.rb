class Author < ApplicationRecord
  has_secure_password

  attr_accessor :password_confirmation
  
  has_many :books
  has_many :read_books, through: :books 

  has_many :readers

  has_many :reading_books

  has_many :want_to_read_books

  validates :email, presence: true, uniqueness: true
  validates :name, presence: true
  validates :password_digest, presence: true
  validates :password_confirmation, presence: true, on: :create



end