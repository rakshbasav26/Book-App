class SessionsController < ApplicationController
  def new
  end

  def create

    author = Author.find_by(email: params[:email])
    reader = Reader.find_by(email: params[:email])

    if author && author.authenticate(params[:password])
      session[:author_id] = author.id
      redirect_to root_path, notice: "Logged in successfully as author!"
    elsif reader && reader.authenticate(params[:password])
      session[:reader_id] = reader.id
      redirect_to root_path, notice: "Logged in successfully as reader!"
    else
      flash[:alert] = "Invalid email or password"
      render :new
    end
  end

  def destroy
    session[:author_id] = nil
    session[:reader_id] = nil
    redirect_to root_path, notice: "Logged out"
  end
end
