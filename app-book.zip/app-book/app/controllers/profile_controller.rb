class ProfileController < ApplicationController


def show
  if current_reader
    @reader = Reader.find(params[:id])
    @read_books = @reader.read_books
    @reading_books = @reader.reading_books
    @want_to_read_books = @reader.want_to_read_books
    @read_books_count = @read_books.count
  else
    @current_author = Author.find(params[:id])
    @current_author_books = @current_author.books
    @author_read_books = @current_author.read_books
    @read_books_count = @current_author.read_books.count
  end
end

 
  def edit
    if current_reader
      @reader = Reader.find(params[:id])
    else
      @author = Author.find(params[:id])
    end

  end

  def update

    if current_reader
      @reader = Reader.find(params[:id])

      if @reader.update(reader_params)
        redirect_to profile_path, notice: 'Profile was successfully updated.'
      else
        render :edit
      end
    else 
      @author = Author.find(params[:id])

      if @author.update(author_params)
        redirect_to profile_path, notice: 'Profile was successfully updated.'
      else
        render :edit
      end
    end
  end

  private
 


  def reader_params
    params.require(:reader).permit(:name, :email)
  end
 
 def author_params
    params.require(:author).permit(:name, :email)
  end

 end

