class ReadersController < ApplicationController

  def new
    @reader = Reader.new
  end

  def create
    @reader = Reader.new(reader_params)
    if @reader.save
      session[:reader_id] = @reader.id
      redirect_to root_path, notice: "Signed up successfully!"
    else
      render :new
    end
  end

 

  def destroy
    @reader = Reader.find(params[:id])
    @reader.destroy
    session[:reader_id] = nil
    redirect_to root_path, notice: "Account deleted successfully!"
  end

  private

  def reader_params
    params.require(:reader).permit(:name, :email, :password_digest, :password_confirmation)
  end
end
