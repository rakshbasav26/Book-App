class BooksController < ApplicationController
  before_action :authenticate_author!, only: [:create, :new]


  def new
    @book = Book.new
    @author_name = session[:author_name]
  end

  def update
    @book = Book.find(params[:id])
    @book.update(book_params)
      flash[:notice] = "Book updated successfully."

    if current_reader
      if @book.update(book_params)
        if params[:book][:read_books] == "1"
          unless current_reader.read_books.exists?(book_id: @book.id)
            ReadBook.create(reader_id: current_reader.id, book_id: @book.id)
          end
        else
          current_reader.read_books.where(book_id: @book.id).destroy_all
        end

        if params[:book][:reading_books] == "1"
          unless current_reader.reading_books.exists?(book_id: @book.id)
            ReadingBook.create(reader_id: current_reader.id, book_id: @book.id)
          end
        else
          current_reader.reading_books.where(book_id: @book.id).destroy_all
        end

        if params[:book][:want_to_read_books] == "1"
          unless current_reader.want_to_read_books.exists?(book_id: @book.id)
            WantToReadBook.create(reader_id: current_reader.id, book_id: @book.id)
          end
        else
          current_reader.want_to_read_books.where(book_id: @book.id).destroy_all
        end

        redirect_to books_path, notice: 'Book status was successfully updated.'
      else
        render 'edit'
      end
    else
      redirect_to root_path, alert: 'You are not authorized to update books.'
    end
  end
  
  def edit
    @book = Book.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    flash[:alert] = "Book not found."
    redirect_to books_path
  end

    def search
      @book = Book.find_by(id: params[:id])
      @books = Book.where("title LIKE ?", "%#{params[:query]}%")  
    end

  
  def show
    @book = Book.find(params[:id])
  end

  def index
    @books = Book.includes(:author).all
    @reader = current_reader
  end

  def create
    @book = current_author.books.build(book_params)
    if @book.save
      redirect_to root_path, notice: "Book added successfully!"
    else
      render :new, status: :unprocessable_entity
    end
  end

  def mybook
    @author = Author.find(session[:author_id]) 
    @books = @author.books
  end
  
  def destroy
    @book = Book.find(params[:id])
    @book.destroy
    redirect_to root_path, notice: "Book deleted successfully!"
  end

  private

  def book_params
    params.require(:book).permit(:title, :summary, :image, :author_name, :description)
  end
end

































































#   def index
#   @reader = current_reader

#   if params[:query].present?
#     @books = Book.includes(:author).where("title LIKE ?", "%#{params[:query]}%")
#   else
#     @books = Book.includes(:author).all
#   end

#   @book = Book.find_by(id: params[:id]) if params[:id].present?
# end