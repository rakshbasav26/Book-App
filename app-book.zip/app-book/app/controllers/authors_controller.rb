class AuthorsController < ApplicationController
  def new
    @author = Author.new
  end

   def create
    @author = Author.new(author_params)
    if @author.save
      session[:author_id] = @author.id
      session[:author_name] = @author.name  
      redirect_to root_path, notice: "Signed up successfully!"
    else
      render :new
    end
  end

  def destroy
    @author = Author.find(params[:id])
    @author.destroy
    session[:author_id] = nil
    redirect_to root_path, notice: "Signed Out"
  end


  private

  def author_params
    params.require(:author).permit(:name, :email, :password_digest, :password_confirmation)
  end
end

