class ApplicationController < ActionController::Base
  helper_method :current_author, :reader_logged_in?, :author_logged_in?, :current_reader




  private
  
  def current_author
    @current_author ||= Author.find_by(id: session[:author_id])
  end

  def author_logged_in?
    !!current_author
  end

  def authenticate_author!
    redirect_to login_path, alert: "Please log in to continue." unless author_logged_in?
  end

  def current_reader
    @current_reader ||= Reader.find(session[:reader_id]) if session[:reader_id]
  end

  def reader_logged_in?
    !!current_reader
  end

 def authenticate_reader!
    redirect_to new_reader_path, alert: "Please log in to continue" unless reader_logged_in?
  end
end
