class ReviewsController < ApplicationController
  before_action :check_if_review_already_exists, only: [:create]
  before_action :set_book
  before_action :set_review, only: [:show, :edit, :update, :destroy]



  def new
    @reader = current_reader
    @review = Review.new
  end

 

  def show

  end

  def create
    @reader = current_reader
    @review = @book.reviews.build(review_params)
    @review.reader = @reader
    if @review.save
      redirect_to root_path, notice: 'Review was successfully created.'
    else
      render :new
    end
  end

 

  def edit
  end

  def update

    if @review.update(review_params)
      flash[:notice] = "Review updated successfully."
      redirect_to root_path
    else
      flash[:alert] = "Error updating review."
      render :edit
    end
  end

  def index
    @reviews = @book.reviews
  end

  def destroy
    @review.destroy
    redirect_to root_path
  end



  private


  def check_if_review_already_exists
    if Review.exists?(book_id: params[:book_id], reader_id: current_reader.id)
      flash[:alert] = "You have already left a review for this book."
      redirect_to book_path(params[:book_id])
    end
  end

  def set_review
    @review = @book.reviews.find_by(id: params[:id])
    unless @review
      redirect_to book_path(@book), alert: 'Review not found.'
    end
  end
 
  def set_book
    @book = Book.find_by(id: params[:book_id])
    unless @book
      redirect_to books_path, alert: 'Book not found.'
    end
  end

  def review_params
    params.require(:review).permit(:content, :rating)
  end
end