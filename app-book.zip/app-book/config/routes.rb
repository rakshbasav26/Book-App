Rails.application.routes.draw do

  get 'login', to: 'sessions#new'
  post 'login', to: 'sessions#create'
  get 'logout', to: 'sessions#destroy'
  delete 'logout', to: 'sessions#destroy'
  get 'mybook', to: 'books#mybook', as: 'mybook'
  get 'search',  to: 'books#search', as: 'search'




  resources :profile
 
  resources :authors, only: [:new, :create, :show, :destroy]
  resources :readers, only: [:new, :create, :show, :destroy]

  
  resources :books do
    resources :reviews
  end

  root 'books#index'

end
