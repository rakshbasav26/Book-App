require "test_helper"

class ReadersControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get readers_new_url
    assert_response :success
  end

  test "should get create" do
    get readers_create_url
    assert_response :success
  end
end
