require "test_helper"

class WantToReadBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
