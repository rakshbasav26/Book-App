require "test_helper"

class ReaderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
