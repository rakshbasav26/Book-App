require "test_helper"

class ReadingBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
