class RemoveReaderIdFromBooks < ActiveRecord::Migration[7.1]
  def change
    remove_column :books, :reader_id, :integer
  end
end
