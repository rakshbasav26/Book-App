class AddWantToReadBooksToBooks < ActiveRecord::Migration[7.1]
  def change
    add_column :books, :want_to_read_books, :boolean
  end
end
