class AddReadingBooksToReaders < ActiveRecord::Migration[7.1]
  def change
    add_column :readers, :reading_books, :boolean
  end
end
