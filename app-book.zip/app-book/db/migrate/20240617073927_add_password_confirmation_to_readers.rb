class AddPasswordConfirmationToReaders < ActiveRecord::Migration[7.1]
  def change
    add_column :readers, :password_confirmation, :string
  end
end
