class AddPasswordConfirmationToAuthors < ActiveRecord::Migration[7.1]
  def change
    add_column :authors, :password_confirmation, :string
  end
end
