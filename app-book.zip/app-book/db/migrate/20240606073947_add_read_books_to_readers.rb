class AddReadBooksToReaders < ActiveRecord::Migration[7.1]
  def change
    add_column :readers, :read_books, :boolean
  end
end
