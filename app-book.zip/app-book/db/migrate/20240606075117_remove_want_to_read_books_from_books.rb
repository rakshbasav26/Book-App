class RemoveWantToReadBooksFromBooks < ActiveRecord::Migration[7.1]
  def change
    remove_column :books, :want_to_read_books, :boolean
  end
end
