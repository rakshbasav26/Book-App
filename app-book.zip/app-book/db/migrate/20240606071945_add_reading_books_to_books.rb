class AddReadingBooksToBooks < ActiveRecord::Migration[7.1]
  def change
    add_column :books, :reading_books, :boolean
  end
end
