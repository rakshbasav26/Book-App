class AddReadingBooksToAuthors < ActiveRecord::Migration[7.1]
  def change
    add_column :authors, :reading_books, :boolean
  end
end
