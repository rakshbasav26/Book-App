class AddReadBooksToBooks < ActiveRecord::Migration[7.1]
  def change
    add_column :books, :read_books, :boolean
  end
end
